﻿using System;
using Android.App;
using Android.OS;
using Android.Util;
using Android.Widget;
using FacetedWorlds.ThoughtCloud.Model;
using UpdateControls;
using UpdateControls.Correspondence;
using UpdateControls.Correspondence.FileStream;
using UpdateControls.Correspondence.POXClient;
using UpdateControls.Correspondence.Strategy;

namespace ThoughtCloud
{
    [Activity(Label = "ThoughtCloud", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : ListActivity
    {
        private Community _community;
        private Identity _identity;
        private ArrayAdapter<string> _cloudArrayAdapter;

        private Dependent _depCloudArray;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            AndroidContext.MainActivity = this;

            _cloudArrayAdapter = new ArrayAdapter<String>(this, Resource.Layout.CloudItem);
            ListAdapter = _cloudArrayAdapter;

            try
            {
                InitializeCommunity();
                InitializeIdentity();
                _community.BeginReceiving();

                _depCloudArray = new Dependent(UpdateCloudArray);
                _depCloudArray.Invalidated += delegate
                {
                    RunOnUiThread(delegate
                    {
                        _depCloudArray.OnGet();
                    });
                };
                _depCloudArray.OnGet();
            }
            catch (Exception ex)
            {
                _cloudArrayAdapter.Add(ex.Message);
                _cloudArrayAdapter.Add(ex.StackTrace);
            }
        }

        private void InitializeCommunity()
        {
            POXConfigurationProvider configurationProvider = new POXConfigurationProvider();
            IStorageStrategy storageStrategy =
                FileStreamStorageStrategy.Load(this, "correspondence");
            _community = new Community(storageStrategy)
                .AddAsynchronousCommunicationStrategy(new POXAsynchronousCommunicationStrategy(configurationProvider))
                .Register<CorrespondenceModel>()
                .Subscribe(() => _identity)
                .Subscribe(() => _identity.SharedClouds)
                ;
        }

        private void InitializeIdentity()
        {
            _identity = _community.AddFact(new Identity("mike"));
        }

        private void UpdateCloudArray()
        {
            Log.WriteLine(LogPriority.Info, "ThoughtCloud", "UpdateCloudArray");
            _cloudArrayAdapter.Clear();
            foreach (Cloud cloud in _identity.SharedClouds)
            {
                Thought centralThought = cloud.CentralThought;
                string text = centralThought == null
                    ? "<null>"
                    : centralThought.Text.Value ?? "<empty>";
                Log.WriteLine(LogPriority.Debug, "ThoughtCloud", String.Format("Adding {0}", text));
                _cloudArrayAdapter.Add(text);
            }
        }
    }
}

