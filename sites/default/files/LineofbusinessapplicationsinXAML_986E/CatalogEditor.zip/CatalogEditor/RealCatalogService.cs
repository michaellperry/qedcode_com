﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CatalogEditor.Logic;

namespace CatalogEditor
{
    public class RealCatalogService : ICatalogService
    {
        public List<Product> LoadProducts()
        {
            return new List<Product>()
            {
                new Product() { Name = "Cake" },
                new Product() { Name = "Pie" }
            };
        }
    }
}
