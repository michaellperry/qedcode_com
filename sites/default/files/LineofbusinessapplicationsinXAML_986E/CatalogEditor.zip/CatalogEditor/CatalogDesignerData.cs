﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CatalogEditor.Logic;

namespace CatalogEditor
{
    public class CatalogDesignerData
    {
        public CatalogViewModel ViewModel
        {
            get
            {
                CatalogViewModel viewModel = new CatalogViewModel(
                    new MockCatalogService(),
                    new CatalogNavigationModel());
                viewModel.Load();
                return viewModel;
            }
        }
    }
}
