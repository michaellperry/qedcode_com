﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CatalogEditor.Logic;

namespace CatalogEditor
{
    public class MockCatalogService : ICatalogService
    {
        public List<Product> LoadProducts()
        {
            return new List<Product>()
            {
                new Product() { Name = "Widget", Price = 142.03m },
                new Product() { Name = "Gadget", Price = 2871.23m }
            };
        }
    }
}
