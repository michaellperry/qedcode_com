﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CatalogEditor.Logic;

namespace CatalogEditor.UnitTest
{
    [TestClass]
    public class CatalogViewModelTest
    {
        private CatalogViewModel _catalogViewModel;

        [TestInitialize]
        public void Initialize()
        {
            MockCatalogService mockService = new MockCatalogService();
            _catalogViewModel = new CatalogViewModel(
                mockService,
                new CatalogNavigationModel());
            _catalogViewModel.Load();
        }

        [TestMethod]
        public void WhenAddAProdut_CanGetTheProduct()
        {
            _catalogViewModel.ProductName = "Pie";
            _catalogViewModel.AddProduct.Execute(null);
            var products = _catalogViewModel.Products;
            Assert.IsTrue(products.Any(product => product.Name == "Pie"));
        }

        [TestMethod]
        public void CanGetProductListFromService()
        {
            var products = _catalogViewModel.Products;
            Assert.AreEqual(2, products.Count());
        }
    }
}
