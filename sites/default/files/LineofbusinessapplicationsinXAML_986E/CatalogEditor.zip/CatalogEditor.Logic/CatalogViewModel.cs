﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using System.Collections.ObjectModel;

namespace CatalogEditor.Logic
{
    public class CatalogViewModel
    {
        private ICatalogService _catalogService;
        private CatalogNavigationModel _navigation;
        private Catalog _catalog = new Catalog();

        private ObservableCollection<ProductViewModel> _productViewModels = new ObservableCollection<ProductViewModel>();

        public CatalogViewModel(
            ICatalogService catalogService,
            CatalogNavigationModel navigation)
        {
            _catalogService = catalogService;
            _navigation = navigation;
        }

        public void Load()
        {
            var products = _catalogService.LoadProducts();
            _catalog.AddAllProducts(products);
            var productViewModels =_catalog.Products
                .Select(product => new ProductViewModel(product));
            foreach (var productViewModel in productViewModels)
            {
                _productViewModels.Add(productViewModel);
            }
        }

        public IEnumerable<ProductViewModel> Products
        {
            get
            {
                return _productViewModels;
            }
        }

        public string ProductName
        {
            get { return _navigation.ProductName; }
            set { _navigation.ProductName = value; }
        }

        public ICommand AddProduct
        {
            get
            {
                return new RelayCommand(
                    () => true,
                    () => AddProductInternal());
            }
        }

        private void AddProductInternal()
        {
            Product product = _catalog.NewProduct();
            product.Name = _navigation.ProductName;
            _productViewModels.Add(new ProductViewModel(product));
        }
    }
}
