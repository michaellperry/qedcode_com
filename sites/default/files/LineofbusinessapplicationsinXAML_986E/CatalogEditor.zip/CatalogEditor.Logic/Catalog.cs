﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CatalogEditor.Logic
{
    public class Catalog
    {
        private List<Product> _products = new List<Product>();

        public IEnumerable<Product> Products
        {
            get { return _products; }
        }

        public Product NewProduct()
        {
            Product product = new Product();
            _products.Add(product);
            return product;
        }

        public void AddAllProducts(IEnumerable<Product> products)
        {
            _products.AddRange(products);
        }
    }
}
