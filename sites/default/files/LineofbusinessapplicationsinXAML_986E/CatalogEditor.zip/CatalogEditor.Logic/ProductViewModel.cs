using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CatalogEditor.Logic
{
    public class ProductViewModel
    {
        private Product _product;

        public ProductViewModel(Product product)
        {
            _product = product;
        }

        public string Name
        {
            get { return _product.Name; }
        }

        public decimal Price
        {
            get { return _product.Price; }
            set { _product.Price = value; }
        }
    }
}
