﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CatalogEditor.Logic
{
    public class CatalogNavigationModel
    {
        private string _productName;

        public string ProductName
        {
            get { return _productName; }
            set { _productName = value; }
        }
    }
}
