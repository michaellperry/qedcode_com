﻿USE [CAP_CQRS]
GO

SELECT SUM(Balance)
FROM AccountBalance
