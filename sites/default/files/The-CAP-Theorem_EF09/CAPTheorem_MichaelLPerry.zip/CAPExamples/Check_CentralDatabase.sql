﻿USE [CAP_CentralDatabase]
GO

SELECT SUM(Balance)
FROM AccountBalance
