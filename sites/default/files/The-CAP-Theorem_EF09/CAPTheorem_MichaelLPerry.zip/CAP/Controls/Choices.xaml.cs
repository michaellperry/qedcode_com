﻿using System.Windows.Controls;

namespace CAP.Controls
{
	public partial class Choices : UserControl
	{
		public Choices()
		{
			// Required to initialize variables
			InitializeComponent();
		}
	}
}