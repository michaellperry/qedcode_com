﻿using System.Windows.Controls;

namespace CAP.Controls
{
	public partial class Definitions : UserControl
	{
		public Definitions()
		{
			// Required to initialize variables
			InitializeComponent();
		}
	}
}