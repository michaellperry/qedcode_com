﻿using System.Windows.Controls;

namespace CAP.Controls
{
	public partial class Conclusion : UserControl
	{
        public Conclusion()
		{
			// Required to initialize variables
			InitializeComponent();
		}
	}
}