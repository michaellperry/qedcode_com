﻿using System;

namespace CAP.Pages
{
    public class PageCentralDatabase : Page
    {
        public PageCentralDatabase(PresentationNavigationModel presentationNavigation)
            : base(presentationNavigation, "CentralDatabase", "Central Database")
        {
        }
    }
}
