﻿
namespace CAP.Pages
{
    public class PageAboutMe : Page
    {
        public PageAboutMe(PresentationNavigationModel presentationNavigation)
            : base(presentationNavigation, "AboutMe", "Michael L Perry")
        {
        }
    }
}
