﻿
namespace CAP.Pages
{
    public class PageConclusion : Page
    {
        public PageConclusion(PresentationNavigationModel presentationNavigation)
            : base(presentationNavigation, "Conclusion", "More Information")
        {
            
        }

    }
}
