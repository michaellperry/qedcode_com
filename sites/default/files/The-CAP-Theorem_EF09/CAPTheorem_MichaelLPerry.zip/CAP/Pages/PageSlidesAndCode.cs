﻿
namespace CAP.Pages
{
    public class PageSlidesAndCode : Page
    {
        public PageSlidesAndCode(PresentationNavigationModel presentationNavigation)
            : base(presentationNavigation, "SlidesAndCode", "Slides and Code")
        {
            
        }

    }
}
